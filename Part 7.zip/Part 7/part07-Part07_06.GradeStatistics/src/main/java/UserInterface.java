/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Diego
 */
import java.util.Scanner;

public class UserInterface {

    private Scanner scan;
    private ScoreList list;

    public UserInterface(Scanner scanner, ScoreList list) {
        this.scan = scanner;
        this.list = list;
    }

    public void run() { //do stuff
        System.out.println("Enter point totals, -1 stops:");
        while (true) {
            int score = Integer.valueOf(this.scan.nextLine());
            if (score == -1) {
                break;
            }
            list.add(score);
        }
        
        //outside the loop after collecting user input for score list
        
        System.out.println("Point average (all): " + this.list.average());
        System.out.print("Point average (passing): ");
        double passingAvg=list.pointAverageOfPassing();
        if (passingAvg<50) {
            System.out.println("-");
        } else {
            System.out.println(passingAvg);
        }
        double passPercent=list.passPercent();
        
        System.out.println("Pass percentage: " + passPercent);
        System.out.println("Grade distribution: ");
        this.list.printGradeDistribution();
        
        
        

    }
}
