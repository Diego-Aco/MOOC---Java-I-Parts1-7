/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Diego
 */
import java.util.ArrayList;
//import java.util.Collections;

public class ScoreList {

    private ArrayList<Integer> scores; //list of all scores
    private ArrayList<Integer> passingScores; //list of only passing scores ie. 50 points min
    private ArrayList<Integer> scoresForGrade0;
    private ArrayList<Integer> scoresForGrade1;
    private ArrayList<Integer> scoresForGrade2;
    private ArrayList<Integer> scoresForGrade3;
    private ArrayList<Integer> scoresForGrade4;
    private ArrayList<Integer> scoresForGrade5;

    public ScoreList() {
        this.scores = new ArrayList();
        this.passingScores = new ArrayList();
        this.scoresForGrade0 = new ArrayList();
        this.scoresForGrade1 = new ArrayList();
        this.scoresForGrade2 = new ArrayList();
        this.scoresForGrade3 = new ArrayList();
        this.scoresForGrade4 = new ArrayList();
        this.scoresForGrade5 = new ArrayList();
    }

    public void add(int score) {
        if (score < 0 || score > 100) { //ignore scores that aren't bw 0-100
            return;
        }
        this.scores.add(score);

        if (score >= 50) { //adds passing scores to instance variable passingScores
            passingScores.add(score);
        }

        //now give the score a grade bw 0-5
        if (score < 50) { // //grade 0: 0-49 pts
            this.scoresForGrade0.add(score);
        } else if (score < 60) { //grade 1: 50-59 pts
            this.scoresForGrade1.add(score);
        } else if (score < 70) { //grade 2: 60-69 pts
            this.scoresForGrade2.add(score);
        } else if (score < 80) { //grade 3: 70-79 pts
            this.scoresForGrade3.add(score);
        } else if (score < 90) { //grade 4: 80-89 pts
            this.scoresForGrade4.add(score);
        } else { //grade 5: 90-100 pts
            this.scoresForGrade5.add(score);
        }
    }

    public double average() {
        double avg = 0;
        if (this.scores.isEmpty()) {
            return avg;
        }
        int sum = 0;
        for (int score : scores) {
            sum += score;
        }
        avg = 1.0 * sum / scores.size();
        return avg;
    }

    public double pointAverageOfPassing() { //returns avg of only the passing scores
        double avg = 0;
        if (this.passingScores.isEmpty()) {
            return avg;
        }
        int sum = 0;
        for (int score : this.passingScores) {
            sum += score;
        }
        avg = 1.0 * sum / this.passingScores.size();
        return avg;
    }

    public double passPercent() {
        double passPercent = 100.0 * this.passingScores.size() / this.scores.size();
        return passPercent;
    }

    public void printRowOfStars(int grade) { //prints a row of stars
        if (grade < 0 || grade > 5) { //if grade is not between 0-5, do nothing bc invalid grade
            System.out.println("Invalid grade given to printRowOfStars method");
            return;
        }

        if (grade == 0) {
            for (int score : this.scoresForGrade0) {
                System.out.print("*");
            }
        } else if (grade == 1) {
            for (int score : this.scoresForGrade1) {
                System.out.print("*");
            }
        } else if (grade == 2) {
            for (int score : this.scoresForGrade2) {
                System.out.print("*");
            }
        } else if (grade == 3) {
            for (int score : this.scoresForGrade3) {
                System.out.print("*");
            }
        } else if (grade == 4) {
            for (int score : this.scoresForGrade4) {
                System.out.print("*");
            }
        } else if (grade == 5) {
            for (int score : this.scoresForGrade5) {
                System.out.print("*");
            }
        }

        System.out.println("");
    }

    public void printGradeDistribution() {
        for (int grade = 5; grade >= 0; grade--) {
            System.out.print(grade + ":");
            printRowOfStars(grade); //method to print number of stars on this line
            //System.out.println();
        }
    }
}
