
import java.io.File;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class RecipeSearch {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        ArrayList<Recipe> recipes = new ArrayList(); //this will store recipe objects from the file;

        System.out.println("File to read: ");

        String fileName = scanner.nextLine(); 
        recipes = readRecipesFromFile(fileName);

        //test
        /*
        Recipe recipe1 = recipes.get(0);
        for (String ingredient : recipe1.getIngredients()) {
            System.out.println(ingredient);
        }
        System.out.println("");
        Recipe recipe2 = recipes.get(1);
        for (String ingredient : recipe2.getIngredients()) {
            System.out.println(ingredient);
        }
        
        System.out.println("");
        Recipe recipe3 = recipes.get(2);
        for (String ingredient : recipe3.getIngredients()) {
            System.out.println(ingredient);
        }

        */
        System.out.println("");
        System.out.println("Commands: ");
        System.out.println("list - lists the recipes");
        System.out.println("stop - stops the program");
        System.out.println("find name - searches recipes by name");
        System.out.println("find cooking time - searches recipes by cooking time");
        System.out.println("find ingredient - searches recipes by ingredient");

        //continually asks for commands until stop is entered
        while (true) {
            System.out.println("");
            System.out.println("Enter command: ");

            String command = scanner.nextLine();

            System.out.println("");
  
            //System.out.println("test: filename is " + fileName);

            if (command.equals("list")) {
                //print all recipes in recipe arraylist
                System.out.println("");
                System.out.println("Recipes: ");
                for (Recipe recipe : recipes) {
                    System.out.println(recipe);
                }
            } else if (command.equals("stop")) {
                break;
            } else if (command.equals("find name")) {
                System.out.println("Searched word: ");
                String searched = scanner.nextLine();
                System.out.println("");
                System.out.println("Recipes: ");
                for (Recipe recipe:recipes) {
                    if (recipe.getName().contains(searched)) {
                        System.out.println(recipe);
                    }
                }
            } else if (command.equals("find cooking time")) {
                System.out.println("Max cooking time: ");
                int maxCookingTime = Integer.valueOf(scanner.nextLine());
                System.out.println("");
                System.out.println("Recipes: ");
                for (Recipe recipe: recipes) {
                    if (recipe.getCookingTime()<=maxCookingTime) {
                        System.out.println(recipe);
                    }
                }
            } else if (command.equals("find ingredient")) {
                System.out.println("Ingredient: ");
                String ingredient = scanner.nextLine();
                System.out.println("");
                System.out.println("Recipes: ");
                for (Recipe recipe: recipes) {
                    if (recipe.getIngredients().contains(ingredient)) {
                        System.out.println(recipe);
                    }
                }
            }
        } //end of while loop ie stops the program

    }

    public static ArrayList<Recipe> readRecipesFromFile(String file) {
        ArrayList<Recipe> recipes = new ArrayList(); //list of all recipes in file
        try ( Scanner fileScanner = new Scanner(Paths.get(file))) {
            ArrayList<String> recipeBlock = new ArrayList();
            //read the file until all lines have been read
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                if (line.isEmpty()) {
                    //we've reached the end of a recipe, so create a new recipe object and then a new ArrayList for the next recipe
                    Recipe recipe = blockToRecipe(recipeBlock);
                    recipes.add(recipe);
                    //new recipeBlock for next recipe
                    recipeBlock = new ArrayList();

                    continue;
                }

                //if the line isn't empty, then we add to the current recipeBlock
                recipeBlock.add(line);
            }
            Recipe recipe = blockToRecipe(recipeBlock);
            recipes.add(recipe);
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
        return recipes;
    }

    //below method seems to work correctly
    public static Recipe blockToRecipe(ArrayList<String> recipeBlock) {
        Recipe recipe;
        String name = recipeBlock.get(0);
        int cookingTime = Integer.valueOf(recipeBlock.get(1));
        recipe = new Recipe(name, cookingTime);
        //then add ingredients to the recipe from the recipeBlock Arraylist
        for (int i = 2; i <= recipeBlock.size() - 1; i++) {
            recipe.addIngredient(recipeBlock.get(i));
        }
        return recipe;
    }

}
