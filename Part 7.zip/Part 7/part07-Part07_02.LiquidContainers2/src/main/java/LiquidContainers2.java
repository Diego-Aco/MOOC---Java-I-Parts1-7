
import java.util.Scanner;

public class LiquidContainers2 {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        Container first = new Container();
        Container second = new Container();

        while (true) {
            System.out.println("First: " + first);
            System.out.println("Second: " + second);
            System.out.print("> ");

            String input = scan.nextLine(); //read input
            String[] parts = input.split(" ");
            String command = parts[0]; //creates variable for command

            if (command.equals("quit")) { //quit is placed here bc "quit" input doesn't have an amount to store in "amount" variable
                break;
            }

            int amount = Integer.valueOf(parts[1]); //creates variable for amount

            if (command.equals("add")) {
                first.add(amount);
            }

            if (command.equals("move")) {
                if (amount < 0 || first.contains() == 0) { //do nothing if amount is neg or if first container is empty
                    continue;
                }
                if (amount > first.contains()) { //if we're trying to move more than first container actually has
                    int firstHelper = first.contains();
                    first.remove(first.contains());
                    second.add(firstHelper);
                    continue;
                }
                //otherwise, amount <= first
                first.remove(amount);
                second.add(amount);
                continue;
            }

            if (command.equals("remove")) {
                second.remove(amount);
            }

        }
    }
}
