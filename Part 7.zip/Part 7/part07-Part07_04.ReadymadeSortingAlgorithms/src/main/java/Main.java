
import java.util.Arrays;
import java.util.Collections;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        // insert test code here
        int[] integers = {3, 1, 5, 99, 3, 12};
        toString(integers);
        Arrays.sort(integers);
        toString(integers);
        System.out.println("");

        ArrayList<String> names = new ArrayList<String>();
        names.add("Diego");
        names.add("Sam");
        names.add("Rick");
        System.out.println(names);
        Collections.sort(names);
        System.out.println(names);
    }

    public static void sort(int[] array) {
        Arrays.sort(array);
    }

    public static void sort(String[] array) {
        Arrays.sort(array);
    }

    public static void sortIntegers(ArrayList<Integer> integers) {
        Collections.sort(integers);
    }

    public static void sortStrings(ArrayList<String> strings) {
        Collections.sort(strings);
    }

    public static void toString(int[] array) {
        System.out.print("{");
        int i = 0;
        while (i <= array.length-1) {
            System.out.print(array[i]);
            if (i != array.length - 1) {
                System.out.print(", ");
            }
            if (i == array.length - 1) {
                System.out.print("}");
            }
            i++;
        }
        System.out.println("");
    }
    
    
}
