
import java.util.Arrays;

public class MainProgram {

    public static void main(String[] args) {
        // write your test code here
        // indices:       0  1  2  3   4
        int[] numbers = {8, 3, 7, 9, 1, 2, 4};
        MainProgram.sort(numbers);
    }

    public static int smallest(int[] array) { //finds smallest value in entire array
        // write your code here
        int smallest = array[0];
        for (int element : array) {
            if (smallest > element) {
                smallest = element;
            }
        }
        return smallest;
    }

    //wrote this to make writing indexOfSmallestFrom method easier
    public static int smallestFromIndex(int[] array, int startingIndex) {
        int smallest = array[startingIndex];
        int index = startingIndex;
        while (index <= array.length - 1) {
            if (smallest > array[index]) {
                smallest = array[index];
            }
            index++;
        }
        return smallest;
    }

    public static int indexOfSmallest(int[] array) {
        int smallest = smallest(array);

        int indexOfSmallest = 0;
        while (indexOfSmallest <= array.length - 1) {
            if (array[indexOfSmallest] == smallest) {
                break;
            } else {
                indexOfSmallest++;
            }
        }
        return indexOfSmallest;
    }

    public static int indexOfSmallestFrom(int[] table, int startIndex) {
        int indexOfSmallest = startIndex; //we'll initially assume indexofsmallest is the parameter startIndex

        //then find smallest value within range of array elements
        int smallest = smallestFromIndex(table, startIndex);

        //then find the index associated with the smallest value
        while (indexOfSmallest <= table.length - 1) {
            if (table[indexOfSmallest] == smallest) {
                break;
            } else {
                indexOfSmallest++;
            }
        }

        return indexOfSmallest;

    }

    public static void swap(int[] array, int index1, int index2) {
        // write your code here
        int firstNum = array[index1];
        int secondNum = array[index2];
        array[index1] = secondNum;
        array[index2] = firstNum;
    }

    public static void sort(int[] array) {
        System.out.println(Arrays.toString(array));
        int index = 0;
        while (index <= array.length - 1) {
            int smallest = smallestFromIndex(array, index);
            int indexOfSmallest = indexOfSmallestFrom(array, index);
            swap(array, index, indexOfSmallest);
            System.out.println(Arrays.toString(array));
            index++;
        }
    }

}
