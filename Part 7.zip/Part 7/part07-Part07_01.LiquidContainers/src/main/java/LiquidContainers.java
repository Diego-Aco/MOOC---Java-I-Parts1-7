
import java.util.Scanner;

public class LiquidContainers {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int first = 0;
        int second = 0;
        while (true) {
            System.out.println("First: " + first + "/100");
            System.out.println("Second: " + second + "/100");
            System.out.print("> ");

            String input = scan.nextLine(); //read input
            String[] parts = input.split(" "); 
            String command = parts[0]; //creates variable for command
            
            if (command.equals("quit")) { //quit is placed here bc "quit" input doesn't have an amount to store in "amount" variable
                break;
            }
            
            int amount = Integer.valueOf(parts[1]); //creates variable for amount
                        
            if (command.equals("add")) {
                if (amount < 0) { //if amount is neg, do nothing and continue loop
                    continue;
                }
                first += amount;
                if (first > 100) { //amount can't go over 100
                    first = 100;
                }
            }
            
            if (command.equals("move")) {
                if (amount<0) {
                    continue;
                }
                if (first==0) { //first container is empty so can't move amounts
                    continue;
                }                
                if (amount>first) { //if we're trying to move more than first container actually has
                    int firstHelper=first;
                    first=0;
                    second+=firstHelper;
                    continue;
                }      
                //otherwise, amount <= first
                first-=amount; 
                /* if (first<0) {
                    first=0;
                } */
                second+=amount;
                if (second>100) {
                    second=100;
                }
            }
            
            if (command.equals("remove")) {
                if (amount>second) {
                    second=0;
                    continue;
                }
                second-=amount;
            }
            
        }

    }
}
