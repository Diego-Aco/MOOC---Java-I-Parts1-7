
import java.nio.file.Paths;
import java.util.Scanner;

public class PrintingASpecifiedFile {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Which file should have its contents printed?");
        String file = input.nextLine();
        
        try (Scanner sc = new Scanner(Paths.get(file))) {
            while(sc.hasNextLine()) {
                String row = sc.nextLine();
                System.out.println(row);
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
