
import java.util.Scanner;
import java.util.ArrayList;

public class NumberOfStrings {

    public static void main(String[] args) {
        
        ArrayList<String> strings = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            String input = scanner.nextLine();
            if (input.equals("end")) {
                break;
            }
            strings.add(input);
        }
        System.out.println(strings.size());
    }
}
