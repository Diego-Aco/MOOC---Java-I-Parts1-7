
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class SportStatistics {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("File: ");
        String file = scan.nextLine();
        System.out.println("Team: ");
        String team = scan.nextLine();
        System.out.print("Games: ");

        //create list of games
        ArrayList<Game> games = readGamesFromFile(file);

        //count up number of games played by the team requested by user input
        int numGames = 0;
        for (Game game : games) {
            if (game.getHomeTeam().equals(team) || game.getVisitTeam().equals(team)) {
                numGames++;
            }
        }

        System.out.println(numGames);

        //count up wins and losses
        int wins = 0;
        int losses = 0;

        for (Game game : games) {
            if (game.getHomeTeam().equals(team)) { //if team is home
                if (game.getHomePoints() > game.getVisitPoints()) {
                    wins++;
                } else {
                    losses++;
                }
            }

            if (game.getVisitTeam().equals(team)) { //if team is visiting
                if (game.getVisitPoints() > game.getHomePoints()) {
                    wins++;
                } else {
                    losses++;
                }
            }
        }
        //outside for loop now
        System.out.println("Wins: " + wins);
        System.out.println("Losses: " + losses);
        

    }

    public static ArrayList<Game> readGamesFromFile(String file) {
        ArrayList<Game> games = new ArrayList();
        //code here
        try ( Scanner fileReader = new Scanner(Paths.get(file))) {
            while (fileReader.hasNextLine()) {
                String line = fileReader.nextLine();
                String[] parts = line.split(",");
                String homeTeam = parts[0];
                String visitTeam = parts[1];
                int homePoints = Integer.valueOf(parts[2]);
                int visitPoints = Integer.valueOf(parts[3]);
                Game game = new Game(homeTeam, visitTeam, homePoints, visitPoints);
                games.add(game);
            }
        } catch (Exception e) {
            System.out.println("Error: " + e);
        }
        return games;
    }
}
