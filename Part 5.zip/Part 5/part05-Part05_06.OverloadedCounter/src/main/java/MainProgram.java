
public class MainProgram {

    public static void main(String[] args) {
        // Test your counter here
        Counter counter = new Counter();
        
        System.out.println("Increasing methods:");
        counter.increase(5);
        counter.increase();
        counter.increase(-1); //should do nothing
        System.out.println(counter.value()); //should print 6
        
        System.out.println();
        System.out.println("Now decrease methods:");
        counter.decrease(2);
        counter.decrease();
        counter.decrease(-1); //should do nothing
        System.out.println(counter.value()); //should print 3
    }
}
