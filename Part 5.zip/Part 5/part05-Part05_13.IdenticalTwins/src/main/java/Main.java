
public class Main {

    public static void main(String[] args) {
        // you can write code here to try out your program
        SimpleDate date = new SimpleDate(24, 3, 2017);
        SimpleDate date2 = new SimpleDate(23, 7, 2017);

        Person leo = new Person("Leo", date, 62, 9);
        Person lily = new Person("Lily", date2, 65, 8);

        if (leo.equals(lily)) {
            System.out.println("Is this quite correct?");
        }

        Person leoWithDifferentWeight = new Person("Leo", date, 62, 10);

        if (leo.equals(leoWithDifferentWeight)) {
            System.out.println("Is this quite correct?");
        }
        
        Person anotherLeo = new Person("Leo", date, 62, 9);
        if (anotherLeo.equals(leo)) {
            System.out.println("anotherLeo is equal to Leo"); //should print
        } else {
            System.out.println("anotherLeo is not equal to Leo");
        }
        
        Person anotherLily = new Person("Lily", date2, 65, 10);
        if (anotherLily.equals(lily)) {
            System.out.println("anotherLily is equal to Lily");
        } else {
            System.out.println("anotherLily is not equal to Lily"); //should print
        }
        
        anotherLeo=new Person("leo", date, 62, 9); //almost the same as original leo object except name isn't capitalized
        if (anotherLeo.equals(leo)) {
            System.out.println("anotherLeo is equal to Leo");
        } else {
            System.out.println("anotherLeo is not equal to Leo"); //should print
        }

        
    }
}
