
import java.util.ArrayList;

public class SimpleCollection {

    private String name;
    private ArrayList<String> elements;

    public SimpleCollection(String name) {
        this.name = name;
        this.elements = new ArrayList<>();
    }

    public void add(String element) {
        this.elements.add(element);
    }

    public ArrayList<String> getElements() {
        return this.elements;
    }

    public String longest() {
        //if the instance variable "elements" is empty, then return null
        if (this.elements.isEmpty()) {
            return null;
        }
        //create longest string variable to be returned
        String longest = "";
        //go through list "elements" and compare current longest String to each element
        for (String elem : this.elements) {
            //now compare longest to current elem, reassigning longest if so
            if (elem.length() > longest.length()) {
                longest = elem;
            }
        }
        return longest;
    }
}
