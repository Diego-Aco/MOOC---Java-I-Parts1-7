
public class Main {

    public static void main(String[] args) {

        // Try out your class here
        MessagingService messServ = new MessagingService();
        Message myMessage = new Message("Diego", "This is my messsage.");
        messServ.add(myMessage);
        myMessage= new Message("Tom", "Hey man!");
        messServ.add(myMessage);
        
        System.out.println(messServ.getMessages());
        System.out.println("");
        
    }
}
