
import java.util.ArrayList;

public class SimpleCollection {

    private String name;
    private ArrayList<String> elements;

    public SimpleCollection(String name) {
        this.name = name;
        this.elements = new ArrayList<>();
    }

    public void add(String element) {
        this.elements.add(element);
    }

    public ArrayList<String> getElements() {
        return this.elements;
    }

    public String toString() {
        String printOutput = "The collection " + this.name;
        

        if (this.elements.isEmpty()) {
            return printOutput + " is empty.";
                
        } 
        
         //form a string from the elements in the list    
        String elems = "";
        for (String element:elements) {
            elems = elems + "\n" + element;
        }
        
        if (this.elements.size() == 1) {
            return printOutput + " has 1 element:" + elems;
        } else {
            return printOutput + " has " + this.elements.size() + " elements:" + elems;
        }
    }

}
