/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Diego
 */
import java.util.ArrayList;
public class Hold {
    private int maxWeight;
    private ArrayList<Suitcase> suitcases;
    
    public Hold(int maxWeight) {
        this.maxWeight=maxWeight;
        this.suitcases=new ArrayList<>();
    }
    
    public String toString() {
        return this.suitcases.size() + " suitcases (" + this.totalHoldWeight() + " kg)";
    }
    
    public void addSuitcase(Suitcase suitcase) {
        if (suitcase.totalWeight()+this.totalHoldWeight()>this.maxWeight) {
            return;
        }
        this.suitcases.add(suitcase);
    }
    
    public int totalHoldWeight() { //add up the weights of all suitcases in the hold
        int totalHoldWeight=0;
        if (this.suitcases.isEmpty()) {
            return totalHoldWeight;
        }
        for (Suitcase suitcase: this.suitcases) {
            totalHoldWeight+=suitcase.totalWeight();
        }
        return totalHoldWeight;
    }
    
    public void printItems() {
        for (Suitcase suitcase: this.suitcases) {
            suitcase.printItems();
        }
    } 
    }
