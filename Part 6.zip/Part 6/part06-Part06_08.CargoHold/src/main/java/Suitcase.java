/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Diego
 */
import java.util.ArrayList;

public class Suitcase {

    private ArrayList<Item> items;
    private int maxWeight;

    public Suitcase(int maxWeight) {
        this.items = new ArrayList<>();
        this.maxWeight = maxWeight;
    }

    public void addItem(Item item) {
        //first, call a method to find total weight of a suitcase object and store in a variable 
        int totalWeight = this.totalWeight();
        if (item.getWeight() + totalWeight > this.maxWeight) {
            return;
        }
        this.items.add(item);
    }

    public String toString() {
        if (this.items.isEmpty()) {
            return "no items (0 kg)";
        } else if (this.items.size() == 1) {
            return "1 item (" + this.totalWeight() + " kg)";
        } else {
            return this.items.size() + " items (" + this.totalWeight() + " kg)";
        }
    }

    public int totalWeight() {
        if (this.items.isEmpty()) {
            return 0;
        }
        int totalWeight = 0;
        for (Item item : this.items) {
            totalWeight += item.getWeight();
        }
        return totalWeight;
    }
    
    public void printItems() {
        for (Item item:this.items) {
            System.out.println(item);
        }
    }
    public Item heaviestItem() {
        if (this.items.isEmpty()) {
            return null;
        }
        Item heaviestItem=this.items.get(0);
        for (Item item:this.items) {
            if (heaviestItem.getWeight()<item.getWeight()) {
                heaviestItem=item;
            }
        }
        return heaviestItem;
    }
}
