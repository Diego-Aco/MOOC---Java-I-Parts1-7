
import java.util.ArrayList;

public class Menu {

    private ArrayList<String> meals;

    public Menu() {
        this.meals = new ArrayList<>();
    }

    // implement the required methods here
    
    public void addMeal(String meal) { //adds meal to the menu, unless it's already on there
        if (this.meals.contains(meal)) {
            return;
        }
        this.meals.add(meal);
    }
    
    public void printMeals() { // prints the meals
        for (String meal:this.meals) {
            System.out.println(meal);
        }
    }
    
    public void clearMenu() {
        this.meals.clear();
    }
   
}
